local E, L, V, P, G = unpack(ElvUI)
local S = E:GetModule('Skins')

local _G = _G
local next = next
local hooksecurefunc = hooksecurefunc

S:AddCallbackForAddon('Blizzard_Settings_Shared', nil, nil, nil, nil, nil, 'blizzardOptions')

local function HandleDropdown(option)
	S:HandleButton(option.Dropdown)
	S:HandleButton(option.DecrementButton)
	S:HandleButton(option.IncrementButton)
end

local function UpdateKeybindButtons(self)
	if not self.bindingsPool then return end -- only the keybinding sections have one

	for panel in self.bindingsPool:EnumerateActive() do
		if not panel.IsSkinned then
			S:HandleButton(panel.Button1)
			S:HandleButton(panel.Button2)
			panel.IsSkinned = true
		end

		if panel.CustomButton then -- push to talk
			S:HandleButton(panel.CustomButton)
		end
	end
end

local function UpdateHeaderExpand(self, expanded)
	if self.collapseTex then
		self.collapseTex:SetAtlas(expanded and 'Soulbinds_Collection_CategoryHeader_Collapse' or 'Soulbinds_Collection_CategoryHeader_Expand', true)
	end

	UpdateKeybindButtons(self)
end

local function HandleCheckbox(checkbox)
	checkbox:CreateBackdrop()
	checkbox.backdrop:SetInside(nil, 4, 4)

	for _, region in next, { checkbox:GetRegions() } do
		if region:IsObjectType('Texture') then
			if region:GetAtlas() == 'checkmark-minimal' then
				if E.private.skins.checkBoxSkin then
					region:SetTexture(E.Media.Textures.Melli)

					local checkedTexture = checkbox:GetCheckedTexture()
					checkedTexture:SetVertexColor(1, .82, 0, 0.8)
					checkedTexture:SetInside(checkbox.backdrop)
				end
			else
				region:SetTexture()
			end
		end
	end
end

local function HandleControlGroup(controls)
	for _, child in next, { controls:GetChildren() } do
		if child.SliderWithSteppers then
			S:HandleStepSlider(child.SliderWithSteppers)
		end

		if child.Checkbox then
			S:HandleCheckBox(child.Checkbox)
		end

		if child.Control then
			HandleDropdown(child.Control)
		end
	end
end

local function HandleMinimalTab(tab)
	tab:StripTextures(nil, true)
	tab:CreateBackdrop('Transparent')

	tab.backdrop:Point('TOPLEFT', 1, E.PixelMode and -10 or -12)
	tab.backdrop:Point('BOTTOMRIGHT', -1, -2)
end

local function CategoryListScrollUpdateChild(child)
	if child.IsSkinned then return end

	child.IsSkinned = true

	if child.Background then
		child.Background:SetAlpha(0)
		child.Background:CreateBackdrop()
		child.Background.backdrop:Point('TOPLEFT', 5, -5)
		child.Background.backdrop:Point('BOTTOMRIGHT', -5, 0)
	end

	local toggle = child.Toggle
	if toggle then
		S:HandleCollapseTexture(toggle, true)

		toggle:Size(18)
		toggle:NudgePoint(4, 2)
	end
end

local function CategoryListScrollUpdate(frame)
	frame:ForEachFrame(CategoryListScrollUpdateChild)
end

local function SettingsListScrollUpdateChild(child)
	if child.IsSkinned then return end

	child.IsSkinned = true

	if child.NineSlice then
		child.NineSlice:SetAlpha(0)
		child:CreateBackdrop('Transparent')
		child.backdrop:Point('TOPLEFT', 15, -30)
		child.backdrop:Point('BOTTOMRIGHT', -30, -5)
	end

	if child.Checkbox then
		HandleCheckbox(child.Checkbox)
	end

	if child.Control then
		HandleDropdown(child.Control)
	end

	local button = child.Button
	if button then
		-- only expandable sections have a header button - the other Buttons are UIPanelButtonTemplate
		if not child.OnExpandedChanged then
			S:HandleButton(button)
		else
			button:StripTextures()

			if button.Left then
				button.Left:SetAlpha(0)
			end

			if button.Middle then
				button.Middle:SetAlpha(0)
			end

			if button.Right then
				button.Right:SetAlpha(0)
			end

			if not button.backdrop then
				button:CreateBackdrop()
				button.backdrop:Point('TOPLEFT', 2, -1)
				button.backdrop:Point('BOTTOMRIGHT', -2, 3)
			end

			if not button.hl then
				button.hl = button:CreateTexture(nil, 'HIGHLIGHT')
				button.hl:SetColorTexture(0.8, 0.8, 0, 0.6)
				button.hl:SetInside(button.backdrop)
				button.hl:SetBlendMode('ADD')
			end

			if not child.collapseTex then
				child.collapseTex = button.backdrop:CreateTexture(nil, 'OVERLAY')
				child.collapseTex:Point('RIGHT', -10, 0)
			end

			UpdateHeaderExpand(child, false)

			if child.EvaluateVisibility then
				hooksecurefunc(child, 'EvaluateVisibility', UpdateHeaderExpand)
			end
		end
	end

	if child.ToggleTest then
		S:HandleButton(child.ToggleTest)

		child.VUMeter:StripTextures()
		child.VUMeter.NineSlice:Hide()
		child.VUMeter:CreateBackdrop()
		child.VUMeter.backdrop:SetInside(nil, 4, 4)
		child.VUMeter.Status:SetStatusBarTexture(E.media.normTex)
		child.VUMeter.Status:SetInside(child.VUMeter.backdrop)

		E:RegisterStatusBar(child.VUMeter.Status)
	end

	if child.PushToTalkKeybindButton then
		S:HandleButton(child.PushToTalkKeybindButton)
	end

	if child.SliderWithSteppers then
		S:HandleStepSlider(child.SliderWithSteppers)
	end

	if child.Button1 then
		S:HandleButton(child.Button1)
	end

	if child.Button2 then
		S:HandleButton(child.Button2)
	end

	if child.Controls then
		for i = 1, #child.Controls do
			local control = child.Controls[i]
			if control.SliderWithSteppers then
				S:HandleStepSlider(control.SliderWithSteppers)
			end
		end
	end

	if child.BaseTab then
		HandleMinimalTab(child.BaseTab)
	end

	if child.RaidTab then
		HandleMinimalTab(child.RaidTab)
	end

	if child.BaseQualityControls then
		HandleControlGroup(child.BaseQualityControls)
	end

	if child.RaidQualityControls then
		HandleControlGroup(child.RaidQualityControls)
	end
end

local function SettingsListScrollUpdate(frame)
	frame:ForEachFrame(SettingsListScrollUpdateChild)
end

function S:Blizzard_Settings_Shared()
	local SettingsPanel = _G.SettingsPanel
	SettingsPanel:StripTextures()
	SettingsPanel.Bg:Hide()

	SettingsPanel:CreateBackdrop('Transparent')
	S:HandleCloseButton(SettingsPanel.ClosePanelButton)
	S:HandleEditBox(SettingsPanel.SearchBox)
	S:HandleButton(SettingsPanel.ApplyButton)
	S:HandleButton(SettingsPanel.CloseButton)

	HandleMinimalTab(SettingsPanel.GameTab)
	HandleMinimalTab(SettingsPanel.AddOnsTab)

	SettingsPanel.CategoryList:CreateBackdrop('Transparent')
	SettingsPanel.CategoryList.backdrop:SetInside()

	S:HandleTrimScrollBar(SettingsPanel.CategoryList.ScrollBar)

	hooksecurefunc(SettingsPanel.CategoryList.ScrollBox, 'Update', CategoryListScrollUpdate)

	SettingsPanel.Container:CreateBackdrop('Transparent')
	SettingsPanel.Container.backdrop:SetInside()
	SettingsPanel.Container.backdrop:Point('BOTTOMRIGHT', -E.Border, E.Border - 1)
	S:HandleButton(SettingsPanel.Container.SettingsList.Header.DefaultsButton)
	S:HandleTrimScrollBar(SettingsPanel.Container.SettingsList.ScrollBar)

	hooksecurefunc(SettingsPanel.Container.SettingsList.ScrollBox, 'Update', SettingsListScrollUpdate)
end
