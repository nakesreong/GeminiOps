local E, L, V, P, G = unpack(ElvUI)
local S = E:GetModule('Skins')

local _G = _G
local hooksecurefunc = hooksecurefunc
local format, next, strmatch = format, next, strmatch

local GetBattlefieldScore = GetBattlefieldScore
local IsActiveBattlefieldArena = IsActiveBattlefieldArena
local FauxScrollFrame_GetOffset = FauxScrollFrame_GetOffset
local NORMAL_FONT_COLOR = NORMAL_FONT_COLOR

S:AddCallbackForAddon('Blizzard_FrameXML', 'SkinWorldStateScore', nil, nil, nil, nil, 'bgscore')

local function UpdateBackdropWidth()
	_G.WorldStateScoreFrame.backdrop:Point('BOTTOMRIGHT', _G.WorldStateScoreScrollFrame:IsShown() and -78 or -102, 25)
end

local myName = format('> %s <', E.myname)
local function UpdateScore()
	local inArena = IsActiveBattlefieldArena()
	local offset = FauxScrollFrame_GetOffset(_G.WorldStateScoreScrollFrame)

	for i = 1, E.Classic and 22 or 20 do -- score rows
		local fullName, _, _, _, _, faction, _, _, _, classToken = GetBattlefieldScore(offset + i)
		if fullName then
			local name, realm = strmatch(fullName, '([^%-]+)(.*)')
			if name == E.myname then
				name = myName
			end

			if realm and realm ~= '' then
				local color

				if inArena then
					color = faction == 1 and '|cffffd100' or '|cff19ff19'
				else
					color = faction == 1 and '|cff00adf0' or '|cffff1919'
				end

				name = format('%s|cffffffff - |r%s%s|r', name, color, realm)
			end

			local classTextColor = E:ClassColor(classToken) or NORMAL_FONT_COLOR
			local nameText = _G['WorldStateScoreButton'..i..'NameText']
			nameText:SetText(name)
			nameText:SetTextColor(classTextColor.r, classTextColor.g, classTextColor.b)
		end
	end

	if not E.Classic then
		UpdateBackdropWidth()
	end
end

function S:SkinWorldStateScore()
	local WorldStateScoreFrame = _G.WorldStateScoreFrame
	WorldStateScoreFrame:EnableMouse(true)

	S:HandleFrame(WorldStateScoreFrame, true, nil, 0, -12, -102, 25)

	local scrollFrame = _G.WorldStateScoreScrollFrame
	scrollFrame:StripTextures()

	local scrollBar = _G.WorldStateScoreScrollFrameScrollBar
	S:HandleScrollBar(scrollBar)

	if not E.Classic then -- Player rows grow all the way under the scroll bar (except in Classic)
		scrollBar:Point('TOPLEFT', scrollFrame, 'TOPRIGHT', 47, -16)
		scrollBar:Point('BOTTOMLEFT', scrollFrame, 'BOTTOMRIGHT', 47, 16)

		-- Adjust the backdrop while the scroll bar is visible
		_G.WorldStateScoreFrameCloseButton:Point('TOPRIGHT', WorldStateScoreFrame.backdrop, 'TOPRIGHT', -9, 0)
	end

	for _, button in next, {
		_G.WorldStateScoreFrameKB,
		_G.WorldStateScoreFrameDeaths,
		_G.WorldStateScoreFrameHK,
		_G.WorldStateScoreFrameDamageDone,
		_G.WorldStateScoreFrameHealingDone,
		_G.WorldStateScoreFrameHonorGained,
		_G.WorldStateScoreFrameName,
		not E.Classic and _G.WorldStateScoreFrameClass or nil,
		not E.Classic and _G.WorldStateScoreFrameTeam or nil,
		not E.Mists and _G.WorldStateScoreFrameMatchmakingRating or nil
	} do
		button:StyleButton()
	end

	S:HandleButton(_G.WorldStateScoreFrameLeaveButton)

	for i = 1, 3 do
		S:HandleTab(_G['WorldStateScoreFrameTab'..i])
	end

	-- Reposition Tabs
	_G.WorldStateScoreFrameTab1:ClearAllPoints()
	_G.WorldStateScoreFrameTab1:Point('TOPLEFT', WorldStateScoreFrame, 'BOTTOMLEFT', -10, 25)
	_G.WorldStateScoreFrameTab2:Point('TOPLEFT', _G.WorldStateScoreFrameTab1, 'TOPRIGHT', -19, 0)
	_G.WorldStateScoreFrameTab3:Point('TOPLEFT', _G.WorldStateScoreFrameTab2, 'TOPRIGHT', -19, 0)

	for i = 1, 7 do -- stat columns
		_G['WorldStateScoreColumn'..i]:StyleButton()
	end

	hooksecurefunc('WorldStateScoreFrame_Update', UpdateScore)
end
