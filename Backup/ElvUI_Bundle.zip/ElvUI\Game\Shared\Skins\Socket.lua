local E, L, V, P, G = unpack(ElvUI)
local S = E:GetModule('Skins')

local _G = _G
local next, unpack = next, unpack
local hooksecurefunc = hooksecurefunc

local C_ItemSocketInfo_GetSocketTypes = C_ItemSocketInfo.GetSocketTypes

S:AddCallbackForAddon('Blizzard_ItemSocketingUI', nil, nil, nil, nil, nil, 'socket')

local function UpdateItemSocketing()
	for i, socket in next, _G.ItemSocketingFrame.SocketingContainer.SocketFrames do
		local gemColor = C_ItemSocketInfo_GetSocketTypes(i)
		local color = E.GemTypeInfo[gemColor]
		if color then
			socket:SetBackdropBorderColor(color.r, color.g, color.b)
		else
			local r, g, b = unpack(E.media.bordercolor)
			socket:SetBackdropBorderColor(r, g, b)
		end
	end
end

function S:Blizzard_ItemSocketingUI()
	local ItemSocketingFrame = _G.ItemSocketingFrame
	S:HandlePortraitFrame(ItemSocketingFrame)

	_G.ItemSocketingFramePortrait:Kill()
	_G.ItemSocketingScrollFrame:StripTextures()
	_G.ItemSocketingScrollFrame:SetTemplate('Transparent')
	_G.ItemSocketingDescription:DisableDrawLayer('BORDER')
	_G.ItemSocketingDescription:DisableDrawLayer('BACKGROUND')

	S:HandleTrimScrollBar(_G.ItemSocketingScrollFrame.ScrollBar)

	local SocketingContainer = ItemSocketingFrame.SocketingContainer
	for _, button in next, SocketingContainer.SocketFrames do
		button:StripTextures()
		button:StyleButton()
		button:SetTemplate(nil, true)

		button.Shine:Kill()
		button.BracketFrame:Kill()
		button.Background:Kill()

		button.Icon:SetTexCoords()
		button.Icon:SetInside()
	end

	local ApplySocketsButton = SocketingContainer.ApplySocketsButton
	ApplySocketsButton:ClearAllPoints()
	ApplySocketsButton:Point('BOTTOMRIGHT', ItemSocketingFrame, 'BOTTOMRIGHT', -5, 5)
	S:HandleButton(ApplySocketsButton)

	hooksecurefunc('ItemSocketingFrame_Update', UpdateItemSocketing)
end
