--[[
# Element: Master Looter Indicator

Toggles the visibility of an indicator based on the unit's master looter status.

## Widget

MasterLooterIndicator - Any UI widget.

## Notes

A default texture will be applied if the widget is a Texture and doesn't have a texture or a color set.

## Examples

    -- Position and size
    local MasterLooterIndicator = self:CreateTexture(nil, 'OVERLAY')
    MasterLooterIndicator:SetSize(16, 16)
    MasterLooterIndicator:SetPoint('TOPRIGHT', self)

    -- Register it with oUF
    self.MasterLooterIndicator = MasterLooterIndicator
--]]

local _, ns = ...
local oUF = ns.oUF

local GetLootMethod = C_PartyInfo.GetLootMethod
local UnitAffectingCombat = UnitAffectingCombat

local function Update(self, event)
	local unit = self.__unit
	local element = self.MasterLooterIndicator

	if not element.combatHide and (event == 'PLAYER_REGEN_DISABLED' or event == 'PLAYER_REGEN_ENABLED') then return end

	--[[ Callback: MasterLooterIndicator:PreUpdate()
	Called before the element has been updated.

	* self - the MasterLooterIndicator element
	--]]
	if(element.PreUpdate) then
		element:PreUpdate()
	end

	local isShown
	if element.combatHide and UnitAffectingCombat(unit) then
		isShown = false
	else
		local method, partyIndex, raidIndex = GetLootMethod()
		if method == 'master' then
			local lootUnit
			if partyIndex then
				if partyIndex == 0 then
					lootUnit = 'player'
				else
					lootUnit = 'party' .. partyIndex
				end
			elseif raidIndex then
				lootUnit = 'raid' .. raidIndex
			end

			isShown = lootUnit and oUF:UnitIsUnit(unit, lootUnit)
		end
	end

	if isShown then
		element:Show()
	else
		element:Hide()
	end

	--[[ Callback: MasterLooterIndicator:PostUpdate(isShown)
	Called after the element has been updated.

	* self    - the MasterLooterIndicator element
	* isShown - indicates whether the element is shown (boolean)
	--]]
	if(element.PostUpdate) then
		return element:PostUpdate(isShown)
	end
end

local function Path(self, ...)
	--[[ Override: MasterLooterIndicator.Override(self, event, ...)
	Used to completely override the internal update function.

	* self  - the parent object
	* event - the event triggering the update (string)
	* ...   - the arguments accompanying the event
	--]]
	return (self.MasterLooterIndicator.Override or Update) (self, ...)
end

local function ForceUpdate(element)
	return Path(element.__owner, 'ForceUpdate')
end

local function Enable(self, unit)
	local element = self.MasterLooterIndicator
	if(element) then
		element.__owner = self
		element.ForceUpdate = ForceUpdate

		self:RegisterEvent('UNIT_FLAGS', Path)
		self:RegisterEvent('GROUP_ROSTER_UPDATE', Path, true)
		self:RegisterEvent('PARTY_LOOT_METHOD_CHANGED', Path, true)
		self:RegisterEvent('PLAYER_REGEN_DISABLED', Path, true)
		self:RegisterEvent('PLAYER_REGEN_ENABLED', Path, true)

		if(element:IsObjectType('Texture') and not element:GetTexture()) then
			element:SetTexture([[Interface\GroupFrame\UI-Group-MasterLooter]])
		end

		return true
	end
end

local function Disable(self)
	local element = self.MasterLooterIndicator
	if(element) then
		element:Hide()

		self:UnregisterEvent('UNIT_FLAGS', Path)
		self:UnregisterEvent('GROUP_ROSTER_UPDATE', Path)
		self:UnregisterEvent('PARTY_LOOT_METHOD_CHANGED', Path)
		self:UnregisterEvent('PLAYER_REGEN_DISABLED', Path)
		self:UnregisterEvent('PLAYER_REGEN_ENABLED', Path)
	end
end

oUF:AddElement('MasterLooterIndicator', Path, Enable, Disable)
