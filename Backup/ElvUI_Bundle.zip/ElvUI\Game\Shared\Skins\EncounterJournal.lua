local E, L, V, P, G = unpack(ElvUI)
local S = E:GetModule('Skins')

local _G = _G
local ipairs, next, rad = ipairs, next, rad
local unpack, select, tinsert = unpack, select, tinsert
local hooksecurefunc = hooksecurefunc

local CreateFrame = CreateFrame
local GetItemQualityByID = C_Item.GetItemQualityByID

local journalBottomTabs = {}
local encounterInfoTabs = {}
local lootQuality = {
	['loottab-set-itemborder-white'] = nil, -- dont show white
	['loottab-set-itemborder-green'] = 2,
	['loottab-set-itemborder-blue'] = 3,
	['loottab-set-itemborder-purple'] = 4,
	['loottab-set-itemborder-orange'] = 5,
	['loottab-set-itemborder-artifact'] = 6,
}

S:AddCallbackForAddon('Blizzard_EncounterJournal', nil, nil, nil, nil, nil, 'encounterjournal')

local function HandleButton(btn, strip, ...)
	S:HandleButton(btn, strip, ...)

	local str = btn:GetFontString()
	if str then
		str:SetTextColor(1, 1, 1)
	end
end

local function ReskinHeader(header)
	for i = 4, 18 do
		select(i, header.button:GetRegions()):SetTexture()
	end

	HandleButton(header.button)

	header.descriptionBG:SetAlpha(0)
	header.descriptionBGBottom:SetAlpha(0)
	header.description:SetTextColor(1, 1, 1)
	header.button.title:SetTextColor(unpack(E.media.rgbvaluecolor))
	header.button.expandedIcon:SetTextColor(1, 1, 1)
	header.button.expandedIcon:SetWidth(20) -- don't wrap the text
end

local SkinOverviewInfo
do -- this prevents a taint trying to force a color lock by setting it to E.noop
	local LockColors = {}
	local function LockValue(button, r, g, b)
		local rr, gg, bb = unpack(E.media.rgbvaluecolor)
		if r ~= rr or gg ~= g or b ~= bb then
			button:SetTextColor(rr, gg, bb)
		end
	end

	local function LockWhite(button, r, g, b)
		if r ~= 1 or g ~= 1 or b ~= 1 then
			button:SetTextColor(1, 1, 1)
		end
	end

	local function LockColor(button, valuecolor)
		if LockColors[button] then return end

		hooksecurefunc(button, 'SetTextColor', (valuecolor and LockValue) or LockWhite)

		LockColors[button] = true
	end

	SkinOverviewInfo = function(frame, _, index)
		local header = frame.overviews[index]
		if not header.IsSkinned then
			ReskinHeader(header)

			LockColor(header.button.title, true)
			LockColor(header.button.expandedIcon)

			header.IsSkinned = true
		end
	end
end

local function SkinOverviewInfoBullets(object)
	local parent = object:GetParent()

	if parent.Bullets then
		for _, bullet in next, parent.Bullets do
			if not bullet.IsSkinned then
				bullet.Text:SetTextColor('P', 1, 1, 1)
				bullet.IsSkinned = true
			end
		end
	end
end

local function SkinAbilitiesInfo()
	local index = 1
	local header = _G['EncounterJournalInfoHeader'..index]
	while header do
		local button = header.button
		if not header.IsSkinned then
			ReskinHeader(header)

			button.bg = CreateFrame('Frame', nil, button)
			button.bg:SetTemplate()
			button.bg:SetOutside(button.abilityIcon)
			button.bg:OffsetFrameLevel(-1)
			button.abilityIcon:SetTexCoord(.08, .92, .08, .92)

			header.IsSkinned = true
		end

		button.bg:SetShown(button.abilityIcon:IsShown())

		index = index + 1
		header = _G['EncounterJournalInfoHeader'..index]
	end
end

local function ItemSetsItemBorder(border, atlas)
	local r, g, b = E:GetItemQualityColor(lootQuality[atlas])

	local parent = border:GetParent()
	parent.Icon.backdrop:SetBackdropBorderColor(r, g, b)
end

local function ItemSetElements(set)
	if E.private.skins.parchmentRemoverEnable then
		if not set.backdrop then
			set:CreateBackdrop()
		end

		set.Background:Hide()
	end

	for _, button in next, set.ItemButtons do
		if not button.Icon.backdrop then
			S:HandleIcon(button.Icon, true)
		end

		local border = button.Border
		if not border.IsSkinned then
			border:SetAlpha(0)

			ItemSetsItemBorder(border, border:GetAtlas()) -- handle first one
			hooksecurefunc(border, 'SetAtlas', ItemSetsItemBorder)

			border.IsSkinned = true
		end
	end
end

local function HandleItemSetsElements(frame)
	frame:ForEachFrame(ItemSetElements)
end

local function InstanceSelectScrollUpdateChild(child)
	if not child.IsSkinned then
		child:SetNormalTexture(E.ClearTexture)
		child:SetPushedTexture(E.ClearTexture)
		child:SetHighlightTexture(E.media.normTex)
		local hl = child:GetHighlightTexture()
		hl:SetVertexColor(0.8, 0.8, 0.8, .25)
		hl:SetInside(child, 3, 3)

		child.bgImage:CreateBackdrop()
		child.bgImage.backdrop:Point('TOPLEFT', 3, -3)
		child.bgImage.backdrop:Point('BOTTOMRIGHT', -4, 2)

		child.IsSkinned = true
	end
end

local function InstanceSelectScrollUpdate(frame)
	frame:ForEachFrame(InstanceSelectScrollUpdateChild)
end

local function BossesScrollUpdateChild(child)
	if not child.IsSkinned then
		S:HandleButton(child)

		local hl = child:GetHighlightTexture()
		hl:SetColorTexture(1, 1, 1, .25)
		hl:SetInside()

		child.text:SetTextColor(1, 1, 1)
		child.text.SetTextColor = E.noop
		child.creature:Point('TOPLEFT', 0, -4)

		child.IsSkinned = true
	end
end

local function BossesScrollUpdate(frame)
	frame:ForEachFrame(BossesScrollUpdateChild)
end

local function LootContainerUpdateChild(child)
	if not child.IsSkinned then
		if child.bossTexture then child.bossTexture:SetAlpha(0) end
		if child.bosslessTexture then child.bosslessTexture:SetAlpha(0) end

		if child.name and child.icon then
			child.icon:SetSize(32, 32)
			child.icon:Point('TOPLEFT', E.PixelMode and 3 or 4, -(E.PixelMode and 7 or 8))
			S:HandleIcon(child.icon, true)
			S:HandleIconBorder(child.IconBorder, child.icon.backdrop)

			child.name:ClearAllPoints()
			child.name:Point('TOPLEFT', child.icon, 'TOPRIGHT', 6, -2)

			-- we only want this when name and icon both exist
			if not child.backdrop then
				child:CreateBackdrop('Transparent')
				child.backdrop:Point('TOPLEFT')
				child.backdrop:Point('BOTTOMRIGHT', 0, 1)
			end
		end

		if child.boss then
			child.boss:ClearAllPoints()
			child.boss:Point('BOTTOMLEFT', 4, 6)
			child.boss:SetTextColor(1, 1, 1)
		end

		if child.slot then
			child.slot:ClearAllPoints()
			child.slot:Point('TOPLEFT', child.name, 'BOTTOMLEFT', 0, -3)
			child.slot:SetTextColor(1, 1, 1)
		end

		if child.armorType then
			child.armorType:ClearAllPoints()
			child.armorType:Point('RIGHT', child, 'RIGHT', -10, 0)
			child.armorType:SetTextColor(1, 1, 1)
		end

		child.IsSkinned = true
	end
end

local function LootContainerUpdate(frame)
	frame:ForEachFrame(LootContainerUpdateChild)
end

local function JourneysListUpdateChild(child)
	-- This check is to avoid separators and headers from being skinned
	if (child.RenownCardFactionName or child.JourneyCardName) and not child.IsSkinned then

		local watchedFactionToggle = child.WatchedFactionToggleFrame
		if watchedFactionToggle and watchedFactionToggle.WatchFactionCheckbox then
			S:HandleCheckBox(watchedFactionToggle.WatchFactionCheckbox)
		end

		child.IsSkinned = true
	end
end

local function JourneysListUpdate(frame)
	frame:ForEachFrame(JourneysListUpdateChild)
end

local function RepositionTabs()
	local previousTab
	for _, tab in next, journalBottomTabs do
		if tab:IsShown() then
			tab:ClearAllPoints()
			if previousTab then
				tab:Point('TOPLEFT', previousTab, 'TOPRIGHT', -5, 0)
			else
				tab:Point('TOPLEFT', _G.EncounterJournal, 'BOTTOMLEFT', -3, 0)
			end

			previousTab = tab
		end
	end
end

local function RepositionInfoTabs()
	local previousTab
	for _, tab in next, encounterInfoTabs do
		if tab:IsShown() then
			tab:ClearAllPoints()
			if previousTab then
				tab:Point('TOPLEFT', previousTab, 'BOTTOMLEFT', 0, -1)
			else
				tab:Point('TOPLEFT', _G.EncounterJournal, 'TOPRIGHT', 1, 0)
			end

			previousTab = tab
		end
	end
end

local function CollapseSetShown(collapse, shown)
	collapse.collapseIndicator:SetShown(shown)
end

local function CollapseSetAtlas(collapse, atlas)
	collapse.collapseIndicator.plus:SetShown(atlas == 'campaign_headericon_closed')
end

local function CollapseMouseUp(btn)
	btn.button:OnClick()
end

local function CreateCollapseButton(frame, button, collapse)
	local btn = CreateFrame('Button', nil, frame)
	btn:Point('TOPLEFT', collapse)
	btn:StripTextures()
	btn:SetTemplate()
	btn:SetFrameLevel(4)
	btn:Size(17)
	btn:Hide()

	btn.button = button
	btn.collapse = collapse

	btn.minus = btn:CreateTexture(nil, 'OVERLAY', nil, 1)
	btn.minus:Size(7, 1) -- this size is different then the plus texture?
	btn.minus:Point('CENTER')
	btn.minus:SetTexture(E.media.blankTex) -- is this supposed to be `E.Media.Textures.MinusButton`

	btn.plus = btn:CreateTexture(nil, 'OVERLAY', nil, 2)
	btn.plus:Size(1, 7)  -- this size is different then the minus texture?
	btn.plus:Point('CENTER')
	btn.plus:SetTexture(E.media.blankTex) -- is this supposed to be `E.Media.Textures.PlusButton`

	btn:HookScript('OnEnter', S.SetModifiedBackdrop)
	btn:HookScript('OnLeave', S.SetOriginalBackdrop)
	btn:SetScript('OnMouseUp', CollapseMouseUp)

	hooksecurefunc(collapse, 'SetShown', CollapseSetShown)
	hooksecurefunc(collapse, 'SetAtlas', CollapseSetAtlas)

	return btn
end

local function HandleCollapseButtons(frame)
	for _, button in next, { frame.ScrollTarget:GetChildren() } do
		local collapse = button.HeaderCollapseIndicator
		if collapse and not collapse.collapseIndicator then
			collapse.collapseIndicator = CreateCollapseButton(frame, button, collapse)
			collapse:SetAlpha(0)
		end
	end
end

-- Active atlas = currently selected activity
local function MonthlyActivitiesNormalAtlas(button, atlas)
	local r, g, b = unpack(E.media.rgbvaluecolor)
	button.NormalTexture:SetColorTexture(r, g, b, atlas == 'activities-incomplete-active' and .25 or 0)

	-- completed rows have black text for the paper art
	if atlas == 'activities-complete' then
		local container = button.TextContainer
		container.NameText:SetFontObject('GameFontHighlightMedium')
		container.NameText:SetTextColor(1, 1, 1)
		container.ConditionsText:SetFontObject('GameFontNormal')
		container.ConditionsText:SetTextColor(1, .82, 0)
	end
end

-- Traveler's Log rows (MonthlyActivitiesButtonTemplate, MonthlySupersedeActivitiesButtonTemplate)
local function MonthlyActivitiesUpdateChild(button)
	if button.IsSkinned then return end

	button:CreateBackdrop()
	button.backdrop:SetInside(button, 0, 1)

	button.NormalTexture:SetInside(button.backdrop)
	MonthlyActivitiesNormalAtlas(button, button.NormalTexture:GetAtlas())
	hooksecurefunc(button, 'SetNormalAtlas', MonthlyActivitiesNormalAtlas)

	-- the template sets the highlight alpha to .3
	local highlight = button.HighlightTexture
	highlight:SetColorTexture(1, 1, 1, .25)
	highlight:SetInside(button.backdrop)
	highlight:SetAlpha(1)

	button.IsSkinned = true
end

local function MonthlyActivitiesUpdate(frame)
	frame:ForEachFrame(MonthlyActivitiesUpdateChild)
end

local function SuggestFrameRefreshDisplay()
	local suggestFrame = _G.EncounterJournal.suggestFrame
	for i, suggestion in ipairs(suggestFrame.suggestions) do
		local sugg = next(suggestion) and suggestFrame['Suggestion'..i]
		if sugg then
			if not sugg.icon.backdrop then
				sugg.icon:CreateBackdrop()
			end

			sugg.icon:SetMask('')
			sugg.icon:SetTexture(suggestion.iconPath)
			sugg.icon:SetTexCoords()
			sugg.iconRing:Hide()
		end
	end
end

local function SuggestFrameUpdateRewards(sugg)
	local rewardData = sugg.reward.data
	if rewardData then
		if not sugg.reward.icon.backdrop then
			sugg.reward.icon:CreateBackdrop(nil, nil, nil, nil, nil, nil, nil, nil, 3)
		end

		sugg.reward.icon:SetMask('')
		sugg.reward.icon:SetTexture(rewardData.itemIcon or rewardData.currencyIcon or [[Interface\Icons\achievement_guildperk_mobilebanking]])
		sugg.reward.icon:SetTexCoords()

		local quality = rewardData.itemID and GetItemQualityByID(rewardData.itemID)
		local r, g, b = E:GetItemQualityColor(quality and quality > 1 and quality)

		sugg.reward.icon.backdrop:SetBackdropBorderColor(r, g, b)
	end
end

local function HandleSideTabs(encounterInfo, tabNames)
	local r, g, b = unpack(E.media.rgbvaluecolor)
	for _, name in next, tabNames do
		local tab = encounterInfo[name]
		tinsert(encounterInfoTabs, tab)

		tab:Size(32)
		tab:CreateBackdrop(nil, true, nil, nil, nil, nil, nil, true) -- glossTex noScale

		tab:SetNormalTexture(E.ClearTexture)
		tab:SetPushedTexture(E.ClearTexture)
		tab:SetDisabledTexture(E.ClearTexture)

		local hl = tab:GetHighlightTexture()
		hl:SetColorTexture(r, g, b, .2)
		hl:SetInside(tab.backdrop)

		tab.selected:Size(36, 32)
		tab.unselected:Size(36, 32)
		tab.unselected:ClearAllPoints()
		tab.unselected:Point('CENTER')
	end
end

function S:Blizzard_EncounterJournal()
	local EJ = _G.EncounterJournal
	S:HandlePortraitFrame(EJ)

	EJ.navBar:StripTextures(true)
	EJ.navBar.overlay:StripTextures(true)

	EJ.navBar:CreateBackdrop()
	EJ.navBar.backdrop:Point('TOPLEFT', -2, 0)
	EJ.navBar.backdrop:Point('BOTTOMRIGHT')
	HandleButton(EJ.navBar.home, true)

	S:HandleEditBox(EJ.searchBox)
	EJ.searchBox:ClearAllPoints()
	EJ.searchBox:Point('TOPLEFT', EJ.navBar, 'TOPRIGHT', 4, 0)

	local MonthlyActivities = EJ.MonthlyActivitiesFrame
	if E.Modern then
		S:HandleTrimScrollBar(_G.EncounterJournalJourneysFrame.ScrollBar)
		S:HandleTrimScrollBar(MonthlyActivities.ScrollBar)
		S:HandleTrimScrollBar(MonthlyActivities.FilterList.ScrollBar)

		if E.global.general.disableTutorialButtons then
			MonthlyActivities.HelpButton:Kill()
		end
	end

	local InstanceSelect = EJ.instanceSelect
	InstanceSelect.bg:Kill()

	S:HandleDropDownBox(InstanceSelect.ExpansionDropdown)
	S:HandleTrimScrollBar(InstanceSelect.ScrollBar)

	-- Bottom tabs
	if E.Modern then
		tinsert(journalBottomTabs, _G.EncounterJournalJourneysTab)
		tinsert(journalBottomTabs, _G.EncounterJournalMonthlyActivitiesTab)
		tinsert(journalBottomTabs, _G.EncounterJournalSuggestTab)
		tinsert(journalBottomTabs, _G.EncounterJournalDungeonTab)
		tinsert(journalBottomTabs, _G.EncounterJournalRaidTab)
		tinsert(journalBottomTabs, _G.EncounterJournalLootJournalTab)
		tinsert(journalBottomTabs, EJ.TutorialsTab)

		for _, tab in next, journalBottomTabs do
			S:HandleTab(tab)
		end

		hooksecurefunc('EncounterJournal_OnShow', RepositionTabs)
		hooksecurefunc('EncounterJournal_CheckAndDisplayTradingPostTab', RepositionTabs)
		hooksecurefunc('EncounterJournal_CheckAndDisplaySuggestedContentTab', RepositionTabs)

		hooksecurefunc(_G.EncounterJournalJourneysFrame.JourneysList, 'Update', JourneysListUpdate)
		hooksecurefunc(_G.EncounterJournalMonthlyActivitiesFrame.ScrollBox, 'Update', HandleCollapseButtons)
	else
		for _, tab in next, {
			_G.EncounterJournalDungeonTab,
			_G.EncounterJournalRaidTab,
		} do
			S:HandleTab(tab)
		end

		_G.EncounterJournalDungeonTab:ClearAllPoints()
		_G.EncounterJournalDungeonTab:Point('TOPLEFT', _G.EncounterJournal, 'BOTTOMLEFT', -10, 0)

		_G.EncounterJournalRaidTab:ClearAllPoints()
		_G.EncounterJournalRaidTab:Point('LEFT', _G.EncounterJournalDungeonTab, 'RIGHT', -19, 0)
	end

	-- Encounter Info Frame
	local EncounterInfo = EJ.encounter.info
	EncounterInfo:SetTemplate('Transparent')

	EncounterInfo.encounterTitle:Kill()

	EncounterInfo.leftShadow:SetAlpha(0) -- dont kill these
	EncounterInfo.rightShadow:SetAlpha(0) -- it will taint

	EncounterInfo.instanceButton.icon:Size(32)
	EncounterInfo.instanceButton.icon:SetTexCoord(0, 1, 0, 1)
	EncounterInfo.instanceButton:SetNormalTexture(E.ClearTexture)
	EncounterInfo.instanceButton:SetHighlightTexture(E.ClearTexture)

	EncounterInfo.model.dungeonBG:Kill()
	_G.EncounterJournalEncounterFrameInfoBG:Height(385)
	_G.EncounterJournalEncounterFrameInfoModelFrameShadow:Kill()

	EncounterInfo.instanceButton:ClearAllPoints()
	EncounterInfo.instanceButton:Point('TOPLEFT', EncounterInfo, 'TOPLEFT', 0, 10)

	EncounterInfo.instanceTitle:ClearAllPoints()
	EncounterInfo.instanceTitle:Point('BOTTOM', EncounterInfo, 'TOP', 10, 15)

	-- Buttons
	EncounterInfo.difficulty:ClearAllPoints()
	EncounterInfo.difficulty:Point('BOTTOMRIGHT', _G.EncounterJournalEncounterFrameInfoBG, 'TOPRIGHT', -5, 7)
	S:HandleDropDownBox(EncounterInfo.difficulty, 120)

	EncounterInfo.LootContainer.filter:ClearAllPoints()
	EncounterInfo.LootContainer.filter:Point('RIGHT', EncounterInfo.difficulty, 'LEFT', -120, 0)
	S:HandleDropDownBox(EncounterInfo.LootContainer.filter, 120)
	S:HandleDropDownBox(EncounterInfo.LootContainer.slotFilter, 100)

	if not E.Modern then
		local reset = EncounterInfo.reset
		reset:StripTextures()
		HandleButton(reset)

		reset:ClearAllPoints()
		reset:Point('TOPRIGHT', EncounterInfo.difficulty, 'TOPLEFT', -10, 0)

		local resetTexture = _G.EncounterJournalEncounterFrameInfoResetButtonTexture
		resetTexture:SetTexture([[Interface\EncounterJournal\UI-EncounterJournalTextures]])
		resetTexture:SetTexCoord(0.90625000, 0.94726563, 0.00097656, 0.02050781)
	end

	S:HandleTrimScrollBar(EncounterInfo.BossesScrollBar)
	S:HandleTrimScrollBar(_G.EncounterJournalEncounterFrameInstanceFrame.LoreScrollBar)

	_G.EncounterJournalEncounterFrameInstanceFrameBG:SetScale(0.85)
	_G.EncounterJournalEncounterFrameInstanceFrameBG:ClearAllPoints()
	_G.EncounterJournalEncounterFrameInstanceFrameBG:Point('CENTER', 0, 15)
	_G.EncounterJournalEncounterFrameInstanceFrame.titleBG:ClearAllPoints()
	_G.EncounterJournalEncounterFrameInstanceFrame.titleBG:Point('TOP', _G.EncounterJournalEncounterFrameInstanceFrameBG, 'TOP', 0, -32)
	_G.EncounterJournalEncounterFrameInstanceFrameTitle:ClearAllPoints()
	_G.EncounterJournalEncounterFrameInstanceFrameTitle:Point('TOP', 0, -85)
	_G.EncounterJournalEncounterFrameInstanceFrameMapButton:ClearAllPoints()
	_G.EncounterJournalEncounterFrameInstanceFrameMapButton:Point('LEFT', 55, -78)

	S:HandleTrimScrollBar(EncounterInfo.overviewScroll.ScrollBar)
	S:HandleTrimScrollBar(EncounterInfo.detailsScroll.ScrollBar)
	S:HandleTrimScrollBar(EncounterInfo.LootContainer.ScrollBar)

	EncounterInfo.detailsScroll:Height(360)
	EncounterInfo.LootContainer:Height(360)
	EncounterInfo.overviewScroll:Height(360)

	-- Side tabs
	HandleSideTabs(EncounterInfo, { 'overviewTab', 'lootTab', 'bossTab', 'modelTab' })
	RepositionInfoTabs()
	hooksecurefunc('EncounterJournal_DisplayInstance', RepositionInfoTabs)

	-- Search
	_G.EncounterJournalSearchResults:StripTextures()
	_G.EncounterJournalSearchResults:SetTemplate()
	_G.EncounterJournalSearchBox.searchPreviewContainer:StripTextures()

	S:HandleCloseButton(_G.EncounterJournalSearchResultsCloseButton)
	S:HandleTrimScrollBar(_G.EncounterJournalSearchResults.ScrollBar)

	if E.Modern then
		-- Suggestions
		for i = 1, _G.AJ_MAX_NUM_SUGGESTIONS do
			local suggestion = EJ.suggestFrame['Suggestion'..i]
			if i == 1 then
				HandleButton(suggestion.button)
				suggestion.button:SetFrameLevel(4)

				S:HandleNextPrevButton(suggestion.prevButton, nil, nil, true)
				S:HandleNextPrevButton(suggestion.nextButton, nil, nil, true)
			else
				HandleButton(suggestion.centerDisplay.button)
			end
		end

		if E.private.skins.parchmentRemoverEnable then
			_G.EncounterJournalInstanceSelectBG:SetAlpha(0)

			MonthlyActivities.Divider:Hide()
			MonthlyActivities.DividerVertical:Hide()
			MonthlyActivities.Bg:SetAlpha(0)
			MonthlyActivities.ThemeContainer:SetAlpha(0)

			hooksecurefunc(MonthlyActivities.ScrollBox, 'Update', MonthlyActivitiesUpdate)

			local suggestFrame = EJ.suggestFrame

			-- Suggestion 1
			local suggestion = suggestFrame.Suggestion1
			suggestion.bg:Hide()
			suggestion:SetTemplate('Transparent')

			local centerDisplay = suggestion.centerDisplay
			centerDisplay.title.text:SetTextColor(1, 1, 1)
			centerDisplay.description.text:SetTextColor(.9, .9, .9)

			local reward = suggestion.reward
			reward.text:SetTextColor(.9, .9, .9)
			reward.iconRing:Hide()
			reward.iconRingHighlight:SetTexture()

			-- Suggestion 2 and 3
			for i = 2, 3 do
				suggestion = suggestFrame['Suggestion'..i]
				suggestion.bg:Hide()
				suggestion:SetTemplate('Transparent')
				suggestion.icon:Point('TOPLEFT', 10, -10)

				centerDisplay = suggestion.centerDisplay
				centerDisplay:ClearAllPoints()
				centerDisplay:Point('TOPLEFT', 85, -10)
				centerDisplay.title.text:SetTextColor(1, 1, 1)
				centerDisplay.description.text:SetTextColor(.9, .9, .9)

				reward = suggestion.reward
				reward.iconRing:Hide()
				reward.iconRingHighlight:SetTexture()
			end

			hooksecurefunc('EJSuggestFrame_RefreshDisplay', SuggestFrameRefreshDisplay)
			hooksecurefunc('EJSuggestFrame_UpdateRewards', SuggestFrameUpdateRewards)
		end
	end

	-- Suggestion Reward Tooltips
	if E.private.skins.blizzard.tooltip then
		local tooltip = _G.EncounterJournalTooltip
		local item1 = tooltip.Item1
		local item2 = tooltip.Item2
		tooltip.NineSlice:SetTemplate('Transparent')
		S:HandleIcon(item1.icon)
		S:HandleIcon(item2.icon)
		item1.IconBorder:Kill()
		item2.IconBorder:Kill()
	end

	local LJ = EJ.LootJournal
	if E.Modern then
		S:HandleTrimScrollBar(LJ.ScrollBar)
	end

	hooksecurefunc(EJ.instanceSelect.ScrollBox, 'Update', InstanceSelectScrollUpdate)

	if E.private.skins.parchmentRemoverEnable then
		if E.Modern then
			LJ:StripTextures()
			LJ:SetTemplate('Transparent')
			LJ:GetRegions():Kill() -- loottab-background

			_G.EncounterJournalJourneysFrame.BorderFrame:StripTextures()
			_G.EncounterJournalInstanceSelect.evergreenBg:StripTextures()
		end

		hooksecurefunc(EncounterInfo.BossesScrollBox, 'Update', BossesScrollUpdate)
		hooksecurefunc(EncounterInfo.LootContainer.ScrollBox, 'Update', LootContainerUpdate)

		hooksecurefunc('EncounterJournal_SetUpOverview', SkinOverviewInfo)
		hooksecurefunc('EncounterJournal_SetBullets', SkinOverviewInfoBullets)
		hooksecurefunc('EncounterJournal_ToggleHeaders', SkinAbilitiesInfo)

		_G.EncounterJournalEncounterFrameInfoBG:Kill()
		EncounterInfo.detailsScroll.child.description:SetTextColor(1, 1, 1)
		EncounterInfo.overviewScroll.child.loreDescription:SetTextColor(1, 1, 1)

		_G.EncounterJournalEncounterFrameInfoDetailsScrollFrameScrollChildDescription:SetTextColor(1, 1, 1)
		_G.EncounterJournalEncounterFrameInfoOverviewScrollFrameScrollChildHeader:Hide()
		_G.EncounterJournalEncounterFrameInfoOverviewScrollFrameScrollChildTitle:SetFontObject('GameFontNormalLarge')
		_G.EncounterJournalEncounterFrameInfoOverviewScrollFrameScrollChildLoreDescription:SetTextColor(1, 1, 1)
		_G.EncounterJournalEncounterFrameInfoOverviewScrollFrameScrollChildTitle:SetTextColor(1, .8, 0)
		_G.EncounterJournalEncounterFrameInfoOverviewScrollFrameScrollChildHeader:SetAlpha(0)
		_G.EncounterJournalEncounterFrameInfoOverviewScrollFrameScrollChild.overviewDescription.Text:SetTextColor('P', 1, 1, 1)

		_G.EncounterJournalEncounterFrameInstanceFrameBG:SetTexCoord(0.71, 0.06, 0.582, 0.08)
		_G.EncounterJournalEncounterFrameInstanceFrameBG:SetRotation(rad(180))
		_G.EncounterJournalEncounterFrameInstanceFrameBG:SetScale(0.7)
		_G.EncounterJournalEncounterFrameInstanceFrameBG:CreateBackdrop()
		_G.EncounterJournalEncounterFrameInstanceFrame.titleBG:SetAlpha(0)
		_G.EncounterJournalEncounterFrameInstanceFrameTitle:FontTemplate(nil, 25)

		local LoreScrollingText = _G.EncounterJournalEncounterFrameInstanceFrame.LoreScrollingFont:GetFontString()
		LoreScrollingText:SetTextColor(1, 1, 1)
	end

	if E.Modern then
		do -- Item Sets
			local ItemSetsFrame = EJ.LootJournalItems.ItemSetsFrame
			S:HandleTrimScrollBar(ItemSetsFrame.ScrollBar)
			S:HandleDropDownBox(ItemSetsFrame.ClassDropdown)

			if E.private.skins.parchmentRemoverEnable then
				EJ.LootJournalItems:StripTextures()
				EJ.LootJournalItems:SetTemplate('Transparent')
			end

			hooksecurefunc(ItemSetsFrame.ScrollBox, 'Update', HandleItemSetsElements)
		end

		local Contents = EJ.TutorialsFrame.Contents
		if E.private.skins.parchmentRemoverEnable then
			Contents:CreateBackdrop()
			Contents:DisableDrawLayer('BACKGROUND')
			Contents.Header:SetTextColor(1, 1, 1)
			Contents.Description:SetTextColor(1, 1, 1)
		end

		S:HandleButton(Contents.StartButton, nil, nil, nil, true)
		Contents.StartButton.backdrop.Center:SetDrawLayer('BACKGROUND', 1)

		local JourneysFrame = _G.EncounterJournalJourneysFrame
		local LevelSkipButton = JourneysFrame.JourneyProgress.LevelSkipButton
		S:HandleButton(LevelSkipButton, nil, nil, nil, true)
		LevelSkipButton:SetNormalFontObject('ElvUIFontSmall')
		LevelSkipButton:SetHighlightFontObject('ElvUIFontSmall')
		LevelSkipButton:SetDisabledFontObject('ElvUIFontSmall')

		S:HandleButton(JourneysFrame.JourneyProgress.OverviewBtn)
		S:HandleButton(JourneysFrame.JourneyOverview.OverviewBtn)
	end
end
