local E, L, V, P, G = unpack(ElvUI)
local S = E:GetModule('Skins')
local TT = E:GetModule('Tooltip')

local _G = _G
local hooksecurefunc = hooksecurefunc

S:AddCallbackForAddon('Blizzard_Contribution', nil, nil, nil, nil, nil, 'contribution')

local function SetupContributeButton(frame)
	if not frame.IsSkinned then
		S:HandleButton(frame.ContributeButton)
		frame.IsSkinned = true
	end

	local statusBar = frame.Status
	if not statusBar.backdrop then
		E:RegisterStatusBar(statusBar)
		statusBar:StripTextures()
		statusBar:CreateBackdrop()
	end
end

local function AddReward(frame, _, rewardID)
	local reward = frame:FindOrAcquireReward(rewardID)
	if not reward.backdrop then
		reward:SetFrameLevel(5)
		reward:CreateBackdrop()

		reward.Border:SetAlpha(0)
		reward.Icon:SetTexCoords()
		reward.Icon:SetDrawLayer('ARTWORK', -1)
		reward.backdrop:SetOutside(reward.Icon)
	end
end

function S:Blizzard_Contribution()
	local MainFrame = _G.ContributionCollectionFrame
	S:HandleCloseButton(MainFrame.CloseButton)
	MainFrame.CloseButton.CloseButtonBackground:SetAlpha(0)

	-- Reward Tooltip
	if E.private.skins.blizzard.tooltip then
		local tooltip = _G.ContributionBuffTooltip
		S:HandleIcon(tooltip.Icon, true)
		tooltip.Border:SetAlpha(0)

		TT:SetStyle(tooltip)
	end

	hooksecurefunc(_G.ContributionMixin, 'SetupContributeButton', SetupContributeButton)
	hooksecurefunc(_G.ContributionMixin, 'AddReward', AddReward)
end
