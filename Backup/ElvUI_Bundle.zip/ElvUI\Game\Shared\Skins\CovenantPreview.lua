local E, L, V, P, G = unpack(ElvUI)
local S = E:GetModule('Skins')

local _G = _G
local hooksecurefunc = hooksecurefunc

S:AddCallbackForAddon('Blizzard_CovenantPreviewUI', nil, nil, nil, nil, nil, 'covenantPreview')

local function Covenant_TryShow(frame, covenantInfo)
	if covenantInfo and not frame.IsSkinned then -- Blizzard bails on nil too
		frame:SetTemplate('Transparent')

		local InfoPanel = frame.InfoPanel
		frame.ModelSceneContainer.ModelSceneBorder:SetAlpha(0)
		InfoPanel:SetTemplate('Transparent')

		if E.private.skins.parchmentRemoverEnable then
			local Title = frame.Title
			Title:DisableDrawLayer('BACKGROUND')
			Title:SetTemplate('Transparent')
			Title.Text:SetTextColor(1, .8, 0)

			frame.Background:SetAlpha(0)
			frame.BorderFrame:SetAlpha(0)

			InfoPanel.Parchment:SetAlpha(0)
		end

		frame.CloseButton.Border:Kill()

		S:HandleCloseButton(frame.CloseButton)
		S:HandleButton(frame.SelectButton)

		frame.IsSkinned = true
	end
end

function S:Blizzard_CovenantPreviewUI()
	local frame = _G.CovenantPreviewFrame
	if E.private.skins.parchmentRemoverEnable then
		local InfoPanel = frame.InfoPanel
		InfoPanel.Name:SetTextColor(1, 1, 1)
		InfoPanel.Location:SetTextColor(1, 1, 1)
		InfoPanel.Description:SetTextColor(1, 1, 1)
		InfoPanel.AbilitiesFrame.AbilitiesLabel:SetTextColor(1, .8, 0)
		InfoPanel.SoulbindsFrame.SoulbindsLabel:SetTextColor(1, .8, 0)
		InfoPanel.CovenantFeatureFrame.Label:SetTextColor(1, .8, 0)
	end

	hooksecurefunc(frame, 'TryShow', Covenant_TryShow)

	frame.ModelSceneContainer.Background:SetTexCoord(0.00970873786408, 0.99029126213592, 0.0092807424594, 0.9907192575406)

	S:HandleCheckBox(_G.TransmogAndMountDressupFrame.ShowMountCheckButton)
end
