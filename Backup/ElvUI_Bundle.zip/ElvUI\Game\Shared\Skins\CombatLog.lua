local E, L, V, P, G = unpack(ElvUI)
local S = E:GetModule('Skins')
local CH = E:GetModule('Chat')

local _G = _G
local ipairs = ipairs
local hooksecurefunc = hooksecurefunc

S:AddCallbackForAddon('Blizzard_CombatLog', nil, nil, nil, nil, nil, function()
	return E.private.chat.enable -- this is always on with the chat module, it's only handle the top bar in combat log chat frame
end)

local function StyleButtons()
	for index in ipairs(_G.Blizzard_CombatLog_Filters.filters) do
		local button = _G['CombatLogQuickButtonFrameButton'..index]
		local text = button and button:GetFontString()
		if text then
			text:FontTemplate(CH.db.tabFont, CH.db.tabFontSize, CH.db.tabFontOutline)
		end
	end
end

-- credit: Aftermathh, edited by Simpy
function S:Blizzard_CombatLog()
	hooksecurefunc('Blizzard_CombatLog_Update_QuickButtons', StyleButtons)
	StyleButtons()

	local bar = _G.CombatLogQuickButtonFrame_Custom
	bar:StripTextures()
	bar:SetTemplate('Transparent')

	bar:ClearAllPoints()
	bar:Point('BOTTOMLEFT', _G.ChatFrame2, 'TOPLEFT', -3, 2)
	bar:Point('BOTTOMRIGHT', _G.ChatFrame2, 'TOPRIGHT', 3, 0)

	_G.CombatLogQuickButtonFrame_CustomTexture:Hide()

	local progress = _G.CombatLogQuickButtonFrame_CustomProgressBar
	progress:SetStatusBarTexture(E.media.normTex)
	progress:SetInside(bar)

	local filter = _G.CombatLogQuickButtonFrame_CustomAdditionalFilterButton
	S:HandleNextPrevButton(filter)

	filter:ClearAllPoints()
	filter:Point('TOPRIGHT', bar, 'TOPRIGHT', -2, -2)
	filter:SetHitRectInsets(0,0,0,0)
	filter:OffsetFrameLevel(3, bar)
	filter:Size(20)
end
