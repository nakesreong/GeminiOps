local E, L, V, P, G = unpack(ElvUI)
local S = E:GetModule('Skins')

local _G = _G
local next = next
local hooksecurefunc = hooksecurefunc

local data = S:AddCallbackForAddon('Blizzard_CooldownViewer', nil, nil, nil, nil, nil, 'cooldownManager')

do
	local X, Y = 2, -1
	function data:PositionViewerTab(_, _, _, x, y)
		if x ~= X or y ~= Y then
			self:ClearAllPoints()
			self:SetPoint('TOPLEFT', _G.CooldownViewerSettings, 'TOPRIGHT', X, Y)
		end
	end
end

function data:PositionTabIcons(point)
	if point == 'CENTER' then return end

	self:ClearAllPoints()
	self:SetPoint('CENTER')
end

function data:HandleHeaders(header)
	header.HighlightMiddle:SetAlpha(0)
	header.HighlightLeft:SetAlpha(0)
	header.HighlightRight:SetAlpha(0)
	header.Middle:Hide()
	header.Left:Hide()
	header.Right:Hide()

	S:HandleButton(header)

	header.IsSkinned = true
end

function data:HandleSettingItem(item)
	if item.IsSkinned then return end

	item.Highlight:SetColorTexture(1, 1, 1, .25)
	item.Highlight:SetAllPoints(item.Icon)
	S:HandleIcon(item.Icon, true)

	item.IsSkinned = true
end

function data:HandleSettingItemPool()
	for frame in self:EnumerateActive() do
		data:HandleSettingItem(frame)
	end
end

function data:CountText(text)
	local db = E.db.general.cooldownManager
	text:SetIgnoreParentScale(true)
	text:ClearAllPoints()
	text:Point(db.countPosition, db.countxOffset, db.countyOffset)
	text:FontTemplate(db.countFont, db.countFontSize, db.countFontOutline)

	local color = db.countFontColor
	if color then
		text:SetTextColor(color.r, color.g, color.b)
	end
end

function data:UpdateTextContainer(container)
	local applications = container.Applications -- a frame holding the text on icon items, the text itself on bar items
	if applications then
		data:CountText(applications.Applications or applications)
	end

	local chargeText = container.ChargeCount and container.ChargeCount.Current
	if chargeText then
		data:CountText(chargeText)
	end
end

function data:UpdateTextBar(bar)
	local db = E.db.general.cooldownManager
	bar.Name:ClearAllPoints()
	bar.Name:Point(db.namePosition, db.namexOffset, db.nameyOffset)
	bar.Name:FontTemplate(db.nameFont, db.nameFontSize, db.nameFontOutline)

	local color = db.nameFontColor
	if color then
		bar.Name:SetTextColor(color.r, color.g, color.b)
	end

	bar.Duration:ClearAllPoints()
	bar.Duration:Point(db.durationPosition, db.durationxOffset, db.durationyOffset)
	bar.Duration:FontTemplate(db.durationFont, db.durationFontSize, db.durationFontOutline)

	color = db.durationFontColor
	if color then
		bar.Duration:SetTextColor(color.r, color.g, color.b)
	end
end

function data:SkinIcon(container, icon)
	data:UpdateTextContainer(container)
	S:HandleIcon(icon, true)

	for _, region in next, { container:GetRegions() } do
		if region:IsObjectType('Texture') then
			local texture = region:GetTexture()
			local atlas = region:GetAtlas()

			if E:NotSecretValue(texture) and texture == 6707800 then
				region:SetTexture(E.media.blankTex)
			elseif E:NotSecretValue(atlas) and atlas == 'UI-HUD-CoolDownManager-IconOverlay' then -- 6704514
				region:SetAlpha(0)
			end
		end
	end
end

function data:SkinBar(frame, bar)
	data:UpdateTextBar(bar)

	local icon = frame.Icon
	bar:Point('LEFT', icon, 'RIGHT', 3, 0)
	data:SkinIcon(icon, icon.Icon)

	local statusBarTex = bar:GetStatusBarTexture()
	statusBarTex:SetTexture(E.media.normTex)
	statusBarTex:ClearTextureSlice()
	statusBarTex:SetTextureSliceMode(0)

	for _, region in next, { bar:GetRegions() } do
		if region:IsObjectType('Texture') then
			local atlas = region:GetAtlas()

			if atlas == 'UI-HUD-CoolDownManager-Bar' then
				region:Point('TOPLEFT', 1, 0)
				region:Point('BOTTOMLEFT', -1, 0)
			elseif atlas == 'UI-HUD-CoolDownManager-Bar-BG' and not region.backdrop then
				region:StripTextures()
				region:CreateBackdrop('Transparent', nil, true)
				region.backdrop:SetOutside()
			end
		end
	end
end

function data:SkinItemFrame(frame)
	if frame.Cooldown then
		E:RegisterCooldown(frame.Cooldown, 'cdmanager')
	end

	if frame.Bar then
		data:SkinBar(frame, frame.Bar)
	elseif frame.Icon then
		data:SkinIcon(frame, frame.Icon)
	end
end

function data:AcquireItemFrame(frame)
	data:SkinItemFrame(frame)
end

function data:HandleViewer(element)
	hooksecurefunc(element, 'OnAcquireItemFrame', data.AcquireItemFrame)

	for frame in element.itemFramePool:EnumerateActive() do
		data:SkinItemFrame(frame)
	end
end

function data:UpdateViewer(element)
	for frame in element.itemFramePool:EnumerateActive() do
		if frame.Bar then
			data:UpdateTextBar(frame.Bar)
			data:UpdateTextContainer(frame.Icon)
		elseif frame.Icon then
			data:UpdateTextContainer(frame)
		end
	end
end

function S:CooldownManager_UpdateViewers()
	data:UpdateViewer(_G.UtilityCooldownViewer)
	data:UpdateViewer(_G.BuffBarCooldownViewer)
	data:UpdateViewer(_G.BuffIconCooldownViewer)
	data:UpdateViewer(_G.EssentialCooldownViewer)
end

do
	local hookedItemPools = {}

	local function RefreshContent(content)
		for _, child in next, { content:GetChildren() } do
			local header = child.Header
			if header and not header.IsSkinned then
				data:HandleHeaders(child.Header)
			end

			local itemPool = child.itemPool
			if itemPool and not hookedItemPools[itemPool] then
				hookedItemPools[itemPool] = true

				data.HandleSettingItemPool(itemPool)

				hooksecurefunc(itemPool, 'Acquire', data.HandleSettingItemPool)
			end
		end
	end

	function data:RefreshLayout()
		local CooldownViewer = _G.CooldownViewerSettings
		RefreshContent(CooldownViewer.CooldownScroll.Content)
		RefreshContent(CooldownViewer.GroupBuffFilter.Scroll.Content)
	end
end

function data:HandleAbilityTabs(viewer)
	if E.Forever then
		for _, tab in next, viewer.TabButtons do
			S:HandleLargeSideTab(tab)
		end

		S:LayoutLargeSideTabs(viewer, viewer.TabButtons)
	else
		for i, tab in next, { viewer.SpellsTab, viewer.AurasTab, viewer.GroupBuffsTab } do
			tab:CreateBackdrop()
			tab:Size(30, 40)

			if i == 1 then
				tab:ClearAllPoints()
				tab:SetPoint('TOPLEFT', viewer, 'TOPRIGHT', 2, -1)

				hooksecurefunc(tab, 'SetPoint', data.PositionViewerTab)
			end

			tab.Icon:ClearAllPoints()
			tab.Icon:SetPoint('CENTER')
			hooksecurefunc(tab.Icon, 'SetPoint', data.PositionTabIcons)

			tab.Background:SetAlpha(0)
			tab.TabGlow:SetAlpha(0)

			tab.SelectedTexture:SetDrawLayer('ARTWORK')
			tab.SelectedTexture:SetColorTexture(1, 0.82, 0, 0.3)
			tab.SelectedTexture:SetAllPoints()

			tab.HighlightTexture:SetColorTexture(1, 1, 1, 0.3)
			tab.HighlightTexture:SetAllPoints()
		end
	end
end

function S:CooldownManager_HandleSettings(viewer)
	S:HandlePortraitFrame(viewer)
	S:HandleEditBox(viewer.SearchBox)
	S:HandleTrimScrollBar(viewer.CooldownScroll.ScrollBar)
	S:HandleTrimScrollBar(viewer.GroupBuffFilter.Scroll.ScrollBar)
	S:HandleButton(viewer.UndoButton)
	S:HandleDropDownBox(viewer.LayoutDropdown)

	data:HandleAbilityTabs(viewer)
	data:RefreshLayout()

	hooksecurefunc(viewer, 'RefreshLayout', data.RefreshLayout)
end

function S:Blizzard_CooldownViewer()
	local db = E.db.general.cooldownManager
	E:UpdateClassColor(db.nameFontColor)
	E:UpdateClassColor(db.durationFontColor)
	E:UpdateClassColor(db.countFontColor)

	data:HandleViewer(_G.UtilityCooldownViewer)
	data:HandleViewer(_G.BuffBarCooldownViewer)
	data:HandleViewer(_G.BuffIconCooldownViewer)
	data:HandleViewer(_G.EssentialCooldownViewer)
	S:CooldownManager_HandleSettings(_G.CooldownViewerSettings)

	local ImportLayoutDialog = _G.CooldownViewerImportLayoutDialog
	ImportLayoutDialog.Border:Hide()
	ImportLayoutDialog:SetTemplate('Transparent')

	S:HandleButton(ImportLayoutDialog.AcceptButton)
	S:HandleButton(ImportLayoutDialog.CancelButton)
	S:HandleEditBox(ImportLayoutDialog.ImportBox)
	S:HandleEditBox(ImportLayoutDialog.LayoutNameEditBox)
	ImportLayoutDialog.LayoutNameEditBox.backdrop:NudgePoint(0, -3, nil, 'TOPLEFT')
	ImportLayoutDialog.LayoutNameEditBox.backdrop:NudgePoint(10, 3, nil, 'BOTTOMRIGHT')

	local LayoutDialog = _G.CooldownViewerLayoutDialog
	LayoutDialog.Border:Hide()
	LayoutDialog:SetTemplate('Transparent')

	S:HandleButton(LayoutDialog.AcceptButton)
	S:HandleButton(LayoutDialog.CancelButton)
	S:HandleEditBox(LayoutDialog.LayoutNameEditBox)
	LayoutDialog.LayoutNameEditBox.backdrop:NudgePoint(0, -3, nil, 'TOPLEFT')
	LayoutDialog.LayoutNameEditBox.backdrop:NudgePoint(0, 3, nil, 'BOTTOMRIGHT')
end
